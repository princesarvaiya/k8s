#Prerequisites

1. Create a namespace for Klera installation and provide its name in installer.sh, default is set to namespace="iiab9-e1.aexp.com"

2. Create 8 persistent volumes with the following capacities:
    a) 500 GB
    b) 50 GB
    c) 40 GB
    d) 12 GB
    e) 5 GB
    f) 5 GB
    g) 5 GB
    h) 1 GB

    Note: Volumes must be shared across the K8s worker nodes, and accessModes must be ReadWriteMany
    
#Installation

1. Run
    $ sh installer.sh

2. It will create, 
    a) 6 deployments, each deployment consists of a single replica of a pod
    b) 6 clusterip services
    c) 3 nodeport services

3. Klera will be accessible at http://<nodeip>:30080/klera
