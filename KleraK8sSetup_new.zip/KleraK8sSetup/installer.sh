#!/bin/bash

#----------Variables Section----------------
maxtimeout=480
counter=0
namespace="iiab9"

export PATH=$PATH:$HOME/.local/bin:$HOME/bin:/usr/local/bin/

echo "Installation Started. Please wait."

#-------------create namespace------
#namespacekube="$(kubectl create namespace $namespace)"
#echo $namespacekube

#----------Creating secret for docker images----------------
echo "Creating image secret"
kubectl create -n $namespace secret docker-registry kleraregcred --docker-server=docker.io --docker-username=yogpal --docker-password=4f31efae-0800-4425-b31e-f2a8e19a4e75

#----------Deploy Volumes ----------------
echo "**************Creating Persistent Volumes..**************"

pv1pv="$(kubectl apply -f persistent-volumes/elastic-search-data-pv.yml)"
echo $pv1pv
pv2pv="$(kubectl apply -f persistent-volumes/klera-content-viewer-pv.yml)"
echo $pv2pv
pv3pv="$(kubectl apply -f persistent-volumes/klera-data-pv.yml)"
echo $pv3pv
pv4pv="$(kubectl apply -f persistent-volumes/klera-license-pv.yml)"
echo $pv4pv
pv5pv="$(kubectl apply -f persistent-volumes/klera-logs-pv.yml)"
echo $pv5pv
pv6pv="$(kubectl apply -f persistent-volumes/klera-rabbit-mq-db-pv.yml)"
echo $pv6pv
pv7pv="$(kubectl apply -f persistent-volumes/klera-reporting-pv.yml)"
echo $pv7pv
pv8pv="$(kubectl apply -f persistent-volumes/klera-sdlc-data-pv.yml)"
echo $pv8pv
echo "**************Deployment of Persistent Volumes is completed**************"

#----------Deploy Volume Claims ----------------
echo "**************Deploying Persistent Volume Claim..**************"
kleracontentviewerpvc="$(kubectl apply -f persistent-volume-claims/kleracontentviewer-pvc.yml -n $namespace)"
echo $kleracontentviewerpvc
elasticsearchdatapvc="$(kubectl apply -f persistent-volume-claims/elasticsearchdata-pvc.yml -n $namespace)"
echo $elasticsearchdatapvc
rabbitmqpvc="$(kubectl apply -f persistent-volume-claims/rabbitmq-pvc.yml -n $namespace)"
echo $rabbitmqpvc
reportingservicepvc="$(kubectl apply -f persistent-volume-claims/reportingservice-pvc.yml -n $namespace)"
echo $reportingservicepvc
kleralicensepvc="$(kubectl apply -f persistent-volume-claims/kleralicense-pvc.yml -n $namespace)"
echo $kleralicensepvc
kleralogspvc="$(kubectl apply -f persistent-volume-claims/kleralogs-pvc.yml -n $namespace)"
echo $kleralogspvc
klerasdlcdatapvc="$(kubectl apply -f persistent-volume-claims/klerasdlcdata-pvc.yml -n $namespace)"
echo $klerasdlcdatapvc
kleradatapvc="$(kubectl apply -f persistent-volume-claims/kleradata-pvc.yml -n $namespace)"
echo $kleradatapvc

#echo "**************Deployment of Persistent Volume Claims is completed**************"

#----------Deploy Pods ----------------
echo "**************Deploying Pod..**************"

# create elasticsearch pod
elasticsearchpod="$(kubectl apply -f deployments/elasticsearch-deployment-def.yml -n $namespace)"
echo $elasticsearchpod
elasticsearchpodname=$(echo ${elasticsearchpod} | cut --delimiter=' ' --fields=1)
echo $elasticsearchpodname
echo "Checking elasticsearch container status.. Please Wait"
elasticsearchclusteripwaitpod="$(kubectl wait --for=condition=available --timeout=300s -n $namespace deployments/elasticsearch-deployment)"
echo $elasticsearchclusteripwaitpod
if [[ $elasticsearchclusteripwaitpod == '' ]]; then
        echo "[*] Pod didn't start in the specified time period, try kubectl -n $namespace describe pod <POD_NAME> to check the status and re-run installer"
        exit
fi
		while true; do
			if [[ $esstartidentification == "indices into cluster_state" ]]; then
				echo "ElasticSearch started successfully" && counter=0 && break
			elif [[ $counter -gt $maxtimeout ]]; then
				echo "Could not start elasticsearch in specified timeout period" && exit
			else
				esstartidentification=$(kubectl logs $elasticsearchpodname -n $namespace | grep  -o "indices into cluster_state")
				((counter = counter + 1)) && sleep 1s
			fi
		done
		
#servicespod="$(kubectl apply -f services/tmp -n $namespace)"
#echo $servicespod
elasticsearchclusterippod="$(kubectl apply -f services/elasticsearch-clusterip-def.yml -n $namespace)"
echo $elasticsearchclusterippod

# create rabbitmq pod
rabbitmqpod="$(kubectl apply -f deployments/rabbitmq-deployment-def.yml -n $namespace)"
echo $rabbitmqpod
echo "Checking RabbitMQ container status.. Please Wait"
rabbitmqreadypod="$(kubectl wait --for=condition=available --timeout=300s -n $namespace deployments/rabbitmq-deployment)"
echo $rabbitmqreadypod
if [[ $rabbitmqreadypod == '' ]]; then
        echo "[*] Pod didn't start in the specified time period, try kubectl -n $namespace describe pod <POD_NAME> to check the status and re-run installer"
        exit
fi
rabbitmqpodname=$(echo ${rabbitmqpod} | cut --delimiter=' ' --fields=1)
echo $rabbitmqpodname
		while true; do
			if [[ $rmqstartidentification == "1/1" ]]; then
				echo "RabbitMQ started successfully" && counter=0 && break
			elif [[ $counter -gt $maxtimeout ]]; then
				echo "Could not start RabbitMQ in specified timeout period" && exit
			else
				rmqstartidentification=$(kubectl get $rabbitmqpodname -n $namespace | grep -o "1/1")
				((counter = counter + 1)) && sleep 1s
			fi
		done
		
rabbitmqclusterippod="$(kubectl apply -f services/rabbitmq-clusterip-def.yml -n $namespace)"
echo $rabbitmqclusterippod

# create klerapecore pod
klerapecorepod="$(kubectl apply -f deployments/klerapecore-deployment-def.yml -n $namespace)"
echo $klerapecorepod
klerapecorepodname=$(echo ${klerapecorepod} | cut --delimiter=' ' --fields=1)
echo $klerapecorepodname
echo "Starting klerapecore container .. Please Wait"
klerapecorereadypod="$(kubectl wait --for=condition=available --timeout=300s -n $namespace deployments/klerapecore-deployment)"
echo $klerapecorereadypod
if [[ $klerapecorereadypod == '' ]]; then
        echo "[*] Pod didn't start in the specified time period, try kubectl -n $namespace describe pod <POD_NAME> to check the status and re-run installer"
        exit
fi
		while true; do
			if [[ $klerastartidentification == "*Group Service Started Successfully#" ]]; then
				echo "klerapecore started successfully" && counter=0 && break
			elif [[ $counter -gt $maxtimeout ]]; then
				echo "Could not able to start klerapecore in specified timeout period" && exit
			else
				klerastartidentification=$(kubectl logs $klerapecorepodname -n $namespace | grep  -o "*Group Service Started Successfully#")
				((counter = counter + 1)) && sleep 1s
			fi
		done
		
klerapecoreclusterippod="$(kubectl apply -f services/klerapecore-clusterip-def.yml -n $namespace)"
echo $klerapecoreclusterippod
klerapecorenodeportpod="$(kubectl apply -f services/klerapecore-nodeport-def.yml -n $namespace)"
echo $klerapecorenodeportpod

# create kleracontentviewer pod
kleracontentviewerpod="$(kubectl apply -f deployments/kleracontentviewerservice-deployment-def.yml -n $namespace)"
echo $kleracontentviewerpod
kleracontentviewerpodname=$(echo ${kleracontentviewerpod} | cut --delimiter=' ' --fields=1)
echo $kleracontentviewerpodname
echo "Checking kleracontentviewer container status.. Please Wait"
kleracontentviewerreadypod="$(kubectl wait --for=condition=available --timeout=300s -n $namespace deployments/kleracontentviewerservice-deployment)"
echo $kleracontentviewerreadypod
if [[ $kleracontentviewerreadypod == '' ]]; then
        echo "[*] Pod didn't start in the specified time period, try kubectl -n $namespace describe pod <POD_NAME> to check the status and re-run installer"
        exit
fi
		while true; do
			if [[ $kcvstartidentification == "1/1" ]]; then
				echo "kleracontentviewer started successfully" && counter=0 && break
			elif [[ $counter -gt $maxtimeout ]]; then
				echo "Could not start kleracontentviewer in specified timeout period" && exit
			else
				kcvstartidentification=$(kubectl get $kleracontentviewerpodname -n $namespace | grep -o "1/1")
				((counter = counter + 1)) && sleep 1s
			fi
		done
		
kleracontentviewerclusterippod="$(kubectl apply -f services/kleracontentviewerservice-clusterip-def.yml -n $namespace)"
echo $kleracontentviewerclusterippod
kleracontentviewernodeportpod="$(kubectl apply -f services/kleracontentviewerservice-nodeport-def.yml -n $namespace)"
echo $kleracontentviewernodeportpod

# create kleraelectron pod
kleraelectronpod="$(kubectl apply -f deployments/electron-deployment-def.yml -n $namespace)"
echo $kleraelectronpod
kleraelectronpodname=$(echo ${kleraelectronpod} | cut --delimiter=' ' --fields=1)
echo $kleraelectronpodname
echo "Checking kleraelectron container status.. Please Wait"
kleraelectronreadypod="$(kubectl wait --for=condition=available --timeout=300s -n $namespace deployments/kleraelectron-deployment)"
echo $kleraelectronreadypod
if [[ $kleraelectronreadypod == '' ]]; then
        echo "[*] Pod didn't start in the specified time period, try kubectl -n $namespace describe pod <POD_NAME> to check the status and re-run installer"
        exit
fi
		while true; do
			if [[ $kestartidentification == "1/1" ]]; then
				echo "kleraelectron started successfully" && counter=0 && break
			elif [[ $counter -gt $maxtimeout ]]; then
				echo "Could not start kleraelectron in specified timeout period" && exit
			else
				kestartidentification=$(kubectl get $kleraelectronpodname -n $namespace | grep -o "1/1")
				((counter = counter + 1)) && sleep 1s
			fi
		done
		
		
kleraelectronclusterippod="$(kubectl apply -f services/electron-clusterip-def.yml -n $namespace)"
echo $kleraelectronclusterippod

# create klerasdlc pod
klerasdlcpod="$(kubectl apply -f deployments/klerasdlc-deployment-def.yml -n $namespace)"
echo $klerasdlcpod
klerasdlcpodname=$(echo ${klerasdlcpod} | cut --delimiter=' ' --fields=1)
echo $klerasdlcpodname
echo "Checking klerasdlc container status.. Please Wait"
klerasdlcreadypod="$(kubectl wait --for=condition=available --timeout=300s -n $namespace deployments/klerasdlc-deployment)"
echo $klerasdlcreadypod
if [[ $klerasdlcreadypod == '' ]]; then
        echo "[*] Pod didn't start in the specified time period, try kubectl -n $namespace describe pod <POD_NAME> to check the status and re-run installer"
        exit
fi
		while true; do
			if [[ $ksdlcstartidentification == "1/1" ]]; then
				echo "klerasdlc started successfully" && counter=0 && break
			elif [[ $counter -gt $maxtimeout ]]; then
				echo "Could not start klerasdlc in specified timeout period" && exit
			else
				ksdlcstartidentification=$(kubectl get $klerasdlcpodname -n $namespace | grep -o "1/1")
				((counter = counter + 1)) && sleep 1s
			fi
		done
		
klerasdlcclusterippod="$(kubectl apply -f services/klerasdlc-clusterip-def.yml -n $namespace)"
echo $klerasdlcclusterippod
klerasdlcnodeportpod="$(kubectl apply -f services/klerasdlc-nodeport-def.yml -n $namespace)"
echo $klerasdlcnodeportpod

echo "**************Deployment of Pods is completed**************"


echo "Installation Completed."
