namespace="iiab9"

while true; do
    read -p "[*] Do you wish to uninstall Klera from namespace: $namespace?" yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) echo "[*] Aborted";exit;;
        * ) echo "[*] Please answer yes or no!";;
    esac
done

echo "[*] Deleting secret"
kubectl delete secret kleraregcred -n $namespace

echo "[*] Deleting deployments"
kubectl delete deploy elasticsearch-deployment -n $namespace
kubectl delete deploy rabbitmq-deployment -n $namespace
kubectl delete deploy klerapecore-deployment -n $namespace
kubectl delete deploy kleracontentviewerservice-deployment -n $namespace
kubectl delete deploy kleraelectron-deployment -n $namespace
kubectl delete deploy klerasdlc-deployment -n $namespace

echo "[*] Deleting services"
kubectl delete svc kleracontentviewerservice-clusterip -n $namespace
kubectl delete svc kleracontentviewerservice-nodeport -n $namespace
kubectl delete svc kleraelectron-clusterip -n $namespace
kubectl delete svc klerasdlc-clusterip -n $namespace
kubectl delete svc klerasdlc-nodeport -n $namespace
kubectl delete svc elasticklera -n $namespace
kubectl delete svc rabbitmq-clusterip -n $namespace
kubectl delete svc klerapecore-clusterip -n $namespace
kubectl delete svc klerapecore-nodeport -n $namespace

while true; do
    read -p "[*] Do you wish to delete the Persistent Volume Claims as well?" yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) echo "[*] Uninstallation complete!";exit;;
        * ) echo "[*] Please answer yes or no!";;
    esac
done

echo "[*] Deleting PVCs"
kubectl delete pvc klera-content-viewer -n $namespace
kubectl delete pvc elastic-search-data -n $namespace
kubectl delete pvc klera-rabbit-mq-db -n $namespace
kubectl delete pvc klera-reporting -n $namespace
kubectl delete pvc klera-license -n $namespace
kubectl delete pvc klera-logs -n $namespace
kubectl delete pvc klera-sdlc-data -n $namespace
kubectl delete pvc klera-data -n $namespace


while true; do
    read -p "[*] Do you wish to delete the Persistent Volumes as well?" yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) echo "[*] Uninstallation complete!";exit;;
        * ) echo "[*] Please answer yes or no!";;
    esac
done

echo "[*] Deleting PVs"
kubectl delete pv klera-content-viewer
kubectl delete pv elastic-search-data
kubectl delete pv klera-rabbit-mq-db
kubectl delete pv klera-reporting
kubectl delete pv klera-license
kubectl delete pv klera-logs
kubectl delete pv klera-sdlc-data
kubectl delete pv klera-data

echo "[*] Uninstallation Complete!"
echo "[*] WARNING: Persisted data may still be present in the volumes!"