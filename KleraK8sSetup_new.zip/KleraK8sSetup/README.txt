#Description

This setup consists of a Kubernetes cluster setup guide in the documents/ folder and the Klera Kubernetes Setup to install Klera.

A guide to upgrade containers on Kubernetes is also included in documents/ keeping future Container releases of Klera in mind.

Klera Containers and Versions in this setup:

kleraelasticsearch:7.1.1
kleraelectron:1.7.9
kleracontentviewerservice:1.0.30
klerapecore:3.2.27.7
sdlc:4.5.32.7
rabbitmq:3.7.4-rc.4-management-alpine

## Klera Installation ##

After you have setup a Kubernetes cluster following the guide "documents/Kubernetes Cluster Setup Guide", you can move ahead with the klera installation.

#Prerequisites

1. Create a namespace for Klera installation and provide its name in installer.sh, default name is set to "iiab9"
    To create the namespace,
    $ kubectl create namespace iiab9

Note - If you wish to change the namespace name in installer.sh, make sure to change it in uninstaller.sh as well!

2. vm.max_map_count must be at least 262144 on all the worker nodes, to check, 
    $ sysctl vm.max_map_count
    To set, 
    $ sysctl -w vm.max_map_count=262144
    
3. Memory requirement:
    a) elasticsearch 6G
    b) rabbitmq 1.5G
    c) kleracontentviewer 1.5G
    d) klerapecore 11.5G
    e) klerasdlc 9.5G
    f) electron 1.5G

4. CPU requirement (vCPUs):
    a) elasticsearch: 8
    b) rabbitmq: 4
    c) kleracontentviewer: 4
    d) klerapecore: 8
    e) klerasdlc: 8
    f) electron: 4

5. Storage requirement (Persistent Volume Claims):
    a) elastic-search-data: 500G
    b) klera-content-viewer: 5G
    c) klera-data: 50G
    d) klera-license: 1G
    e) klera-logs: 12G
    f) klera-sdlc-data: 40G
    g) klera-rabbit-mq-db: 5G
    h) klera-reporting: 5G

#Installation

1. Run
    $ sh installer.sh

2. It will create, 
    a) 6 deployments, each deployment consists of a single replica of a pod
    b) 6 clusterip services
    c) 3 nodeport services

3. Klera will be accessible at http://<nodeip>:30080/klera

#Uninstallation

1. To uninstall the installed Kubernetes objects, run
    $ sh uninstaller.sh